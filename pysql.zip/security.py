import os
import hashlib
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
import base64
import binascii

class RSAEncryptor:
    def __init__(self):
        self.public_key = None
        self.private_key = None

    def set_public_key(self, public_key):
        self.public_key = public_key

    def set_private_key(self, private_key):
        self.private_key = private_key

    def encrypt_password(self, password):
        # 使用SHA-256进行密码加密
        hash_object = hashlib.sha256(password.encode())
        return hash_object.hexdigest()

    def verify_password(self, stored_password, input_password):
        return stored_password == self.encrypt_password(input_password)

    def encrypt_data(self, data):
        if not self.public_key:
            raise Exception("公钥未设置，无法加密数据")
        # 加载公钥
        public_key = RSA.import_key(self.public_key)
        cipher = PKCS1_OAEP.new(public_key)
        # 加密数据
        encrypted_data = cipher.encrypt(data.encode())
        # 返回Base64编码的密文
        return base64.b64encode(encrypted_data).decode()

    def decrypt_data(self, encrypted_data):
        if not self.private_key:
            raise Exception("私钥未设置，无法解密数据")
        
        # 确保加密数据是有效的 Base64 编码
        encrypted_data = encrypted_data.strip()
        # 计算需要填充的字符数
        missing_padding = len(encrypted_data) % 4
        if missing_padding:
            encrypted_data += '=' * (4 - missing_padding)
        
        try:
            # 解码 Base64 编码的密文
            encrypted_data_bytes = base64.b64decode(encrypted_data)
        except binascii.Error as e:
            raise Exception(f"无效的 Base64 编码: {str(e)}")
        
        # 加载私钥
        private_key = RSA.import_key(self.private_key)
        cipher = PKCS1_OAEP.new(private_key)
        # 解密数据
        decrypted_data = cipher.decrypt(encrypted_data_bytes)
        return decrypted_data.decode()

    # 生成密钥对（仅用于测试，实际应用中用户应自行生成并管理密钥）
    def generate_rsa_keys(self):
        key = RSA.generate(2048)
        private_key = key.export_key()
        public_key = key.publickey().export_key()
        return public_key, private_key