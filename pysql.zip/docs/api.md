# SQL Python API 文档

## 基础信息

- **基础 URL**: `http://127.0.0.1:5000/api`
- **内容类型**: `application/json`

## 认证

所有 API 请求都需要用户登录认证。登录后，系统会返回一个会话 Cookie，后续请求需要携带此 Cookie。

### 登录

- **URL**: `/login`
- **方法**: POST
- **参数**:
  - `username` (string, required): 用户名
  - `password` (string, required): 密码
- **示例**:

  ```bash
  curl -X POST -d "username=admin&password=your_password" http://127.0.0.1:5000/login