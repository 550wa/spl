class Database:
    def __init__(self, name):
        self.name = name
        self.tables = {}  # 存储表对象，键为表名
        self.admin_created = False  # 标记admin是否已创建

    def create_table(self, table_name, columns):
        # 检查表是否已存在
        if table_name in self.tables:
            raise ValueError(f"表 {table_name} 已存在")
        # 创建表对象并添加到数据库
        table = Table(table_name, columns)
        self.tables[table_name] = table
        # 持久化表结构（可选）
        self._save_table_structure(table_name, columns)
        return table

    def _save_table_structure(self, table_name, columns):
        # 实现表结构的持久化逻辑，例如写入配置文件或元数据表
        pass

class Table:
    def __init__(self, name, columns):
        self.name = name
        self.columns = columns  # 列定义，包含列名和数据类型
        self.data = []  # 表数据，存储为列表，每个元素代表一行数据

    def insert(self, row):
        # 检查数据类型和列数是否匹配
        if len(row) != len(self.columns):
            raise ValueError("列数不匹配")
        self.data.append(row)

    def select(self, columns=None, condition=None):
        # 如果未指定列，默认选择所有列
        if columns is None:
            columns = list(self.columns.keys())
        # 筛选符合条件的行
        result = []
        for row in self.data:
            if condition is None or self._matches_condition(row, condition):
                # 提取指定列的数据
                selected_row = [row[list(self.columns.keys()).index(col)] for col in columns]
                result.append(selected_row)
        return result

    def _matches_condition(self, row, condition):
        # 简单条件匹配逻辑，实际项目中需更复杂的解析
        column, operator, value = condition
        col_index = list(self.columns.keys()).index(column)
        col_value = row[col_index]
        # 根据操作符判断是否匹配
        if operator == '=':
            return col_value == value
        elif operator == '!=':
            return col_value != value
        # 可扩展其他操作符
        else:
            raise NotImplementedError(f"操作符 {operator} 尚未实现")