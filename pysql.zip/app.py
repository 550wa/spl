from flask import Flask, render_template, request, jsonify, session, redirect, url_for
import os
from database import Database, Table
from security import RSAEncryptor
import json

app = Flask(__name__)
app.secret_key = os.urandom(24)  # 用于Flask session加密

# 初始化数据库
database = Database("SQL_Python_DB")
rsa_encryptor = RSAEncryptor()

# 密码文件路径
PASSWORD_FILE = "admin_password.json"

# 初始化时创建admin用户
def init_admin():
    if not database.admin_created:
        # 检查是否已存在admin用户
        if 'users' not in database.tables:
            # 创建users表
            users_table = database.create_table('users', {
                'username': str,
                'password': str
            })
        else:
            users_table = database.tables['users']
        # 检查是否已有admin用户
        admin_exists = False
        for row in users_table.data:
            if row[0] == 'admin':
                admin_exists = True
                break
        if not admin_exists:
            # 创建admin用户
            admin_password = input("首次启动，请设置admin密码：")
            encrypted_password = rsa_encryptor.encrypt_password(admin_password)
            users_table.insert(['admin', encrypted_password])
            database.admin_created = True
            # 保存密码到文件
            save_password(admin_password)
        else:
            database.admin_created = True

# 保存密码到文件
def save_password(password):
    encrypted_password = rsa_encryptor.encrypt_password(password)
    with open(PASSWORD_FILE, 'w') as f:
        json.dump({"password": encrypted_password}, f)

# 从文件加载密码
def load_password():
    if os.path.exists(PASSWORD_FILE):
        with open(PASSWORD_FILE, 'r') as f:
            data = json.load(f)
            return data.get("password")
    return None

# 初始化admin用户
init_admin()

# 首页
@app.route('/')
def index():
    # 检查用户是否已登录
    if 'username' not in session:
        return redirect(url_for('login'))
    # 获取所有表名并传递给前端模板
    tables = list(database.tables.keys())
    return render_template('index.html', tables=tables)

# 登录页面
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        # 验证用户名和密码
        if 'users' in database.tables:
            users_table = database.tables['users']
            for row in users_table.data:
                if row[0] == username and rsa_encryptor.verify_password(row[1], password):
                    session['username'] = username
                    return redirect(url_for('index'))
        return render_template('login.html', error='用户名或密码错误')
    return render_template('login.html')

# 注销
@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

# 查看表数据
@app.route('/table/<table_name>', methods=['GET'])
def view_table(table_name):
    # 检查用户是否已登录
    if 'username' not in session:
        return redirect(url_for('login'))
    # 获取指定表的结构和数据
    table = database.tables.get(table_name)
    if not table:
        return "表不存在", 404
    columns = list(table.columns.keys())
    data = table.data

    # 检查私钥是否已设置
    if not rsa_encryptor.private_key:
        return "私钥未设置，无法解密数据。请上传私钥。", 400

    # 对数据进行解密
    decrypted_data = []
    for row in data:
        decrypted_row = [rsa_encryptor.decrypt_data(cell) for cell in row]
        decrypted_data.append(decrypted_row)
    return render_template('table.html', table_name=table_name, columns=columns, data=decrypted_data)

# 执行SQL语句
@app.route('/execute', methods=['POST'])
def execute_sql():
    # 检查用户是否已登录
    if 'username' not in session:
        return jsonify({"error": "未登录"}), 401
    sql = request.form.get('sql')
    # 这里需要实现SQL解析和执行逻辑
    # 示例：简单解析SELECT语句
    if sql.lower().startswith('select'):
        # 简单解析表名和条件（实际项目中需更复杂的解析）
        parts = sql.split()
        table_name = parts[3]  # 假设SQL格式为 "SELECT * FROM table_name"
        table = database.tables.get(table_name)
        if not table:
            return jsonify({"error": "表不存在"}), 404
        # 获取所有数据作为示例
        data = table.data
        # 对数据进行解密
        decrypted_data = []
        for row in data:
            decrypted_row = [rsa_encryptor.decrypt_data(cell) for cell in row]
            decrypted_data.append(decrypted_data)
        return jsonify({"data": decrypted_data})
    elif sql.lower().startswith('insert'):
        # 简单解析INSERT语句（实际项目中需更复杂的解析）
        # 假设SQL格式为 "INSERT INTO table_name VALUES (...)"
        parts = sql.split()
        table_name = parts[2]
        values_start = parts.index('VALUES') + 1
        values = parts[values_start].strip('()').split(',')
        table = database.tables.get(table_name)
        if not table:
            return jsonify({"error": "表不存在"}), 404
        # 对数据进行加密
        encrypted_values = [rsa_encryptor.encrypt_data(value.strip("'")) for value in values]
        try:
            table.insert(encrypted_values)
            return jsonify({"message": "插入成功"})
        except Exception as e:
            return jsonify({"error": str(e)}), 400
    else:
        return jsonify({"error": "不支持的SQL语句"}), 400

# 上传公钥文件
@app.route('/upload_public_key', methods=['POST'])
def upload_public_key():
    if 'public_key_file' not in request.files:
        return jsonify({"error": "未上传公钥文件"}), 400
    
    file = request.files['public_key_file']
    if file.filename == '':
        return jsonify({"error": "未选择公钥文件"}), 400
    
    if file:
        public_key = file.read().decode('utf-8')
        rsa_encryptor.set_public_key(public_key)
        return jsonify({"message": "公钥上传成功"})
    else:
        return jsonify({"error": "公钥上传失败"}), 400

# 上传私钥文件
@app.route('/upload_private_key', methods=['POST'])
def upload_private_key():
    if 'private_key_file' not in request.files:
        return jsonify({"error": "未上传私钥文件"}), 400
    
    file = request.files['private_key_file']
    if file.filename == '':
        return jsonify({"error": "未选择私钥文件"}), 400
    
    if file:
        private_key = file.read().decode('utf-8')
        rsa_encryptor.set_private_key(private_key)
        return jsonify({"message": "私钥上传成功"})
    else:
        return jsonify({"error": "私钥上传失败"}), 400

# API接口：获取所有表名
@app.route('/api/tables', methods=['GET'])
def get_tables():
    # 检查用户是否已登录
    if 'username' not in session:
        return jsonify({"error": "未登录"}), 401
    tables = list(database.tables.keys())
    return jsonify(tables)

# API接口：获取表数据
@app.route('/api/table/<table_name>', methods=['GET'])
def get_table_data(table_name):
    # 检查用户是否已登录
    if 'username' not in session:
        return jsonify({"error": "未登录"}), 401
    table = database.tables.get(table_name)
    if not table:
        return jsonify({"error": "表不存在"}), 404
    columns = list(table.columns.keys())
    data = table.data

    # 检查私钥是否已设置
    if not rsa_encryptor.private_key:
        return jsonify({"error": "私钥未设置，无法解密数据"}), 400

    # 对数据进行解密
    decrypted_data = []
    for row in data:
        decrypted_row = [rsa_encryptor.decrypt_data(cell) for cell in row]
        decrypted_data.append(decrypted_data)
    return jsonify({"columns": columns, "data": decrypted_data})

# API接口：插入数据
@app.route('/api/table/<table_name>', methods=['POST'])
def insert_data(table_name):
    # 检查用户是否已登录
    if 'username' not in session:
        return jsonify({"error": "未登录"}), 401
    table = database.tables.get(table_name)
    if not table:
        return jsonify({"error": "表不存在"}), 404
    # 获取请求数据，假设为JSON格式
    data = request.json.get('data')
    if not data:
        return jsonify({"error": "数据不能为空"}), 400
    try:
        # 对数据进行加密
        encrypted_data = [rsa_encryptor.encrypt_data(str(cell)) for cell in data]
        table.insert(encrypted_data)
        return jsonify({"message": "插入成功"})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# API接口：更新数据
@app.route('/api/table/<table_name>', methods=['PUT'])
def update_data(table_name):
    # 检查用户是否已登录
    if 'username' not in session:
        return jsonify({"error": "未登录"}), 401
    table = database.tables.get(table_name)
    if not table:
        return jsonify({"error": "表不存在"}), 404
    # 获取请求数据，假设为JSON格式
    data = request.json.get('data')
    condition = request.json.get('condition')
    if not data or not condition:
        return jsonify({"error": "数据或条件不能为空"}), 400
    try:
        # 对数据进行加密
        encrypted_data = [rsa_encryptor.encrypt_data(str(cell)) for cell in data]
        # 简单更新逻辑，实际项目中需更复杂的解析
        updated_rows = 0
        for i in range(len(table.data)):
            if rsa_encryptor.decrypt_data(table.data[i][0]) == condition:
                table.data[i] = encrypted_data
                updated_rows += 1
        return jsonify({"message": f"更新了 {updated_rows} 行"})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# API接口：删除数据
@app.route('/api/table/<table_name>', methods=['DELETE'])
def delete_data(table_name):
    # 检查用户是否已登录
    if 'username' not in session:
        return jsonify({"error": "未登录"}), 401
    table = database.tables.get(table_name)
    if not table:
        return jsonify({"error": "表不存在"}), 404
    # 获取请求数据，假设为JSON格式
    condition = request.json.get('condition')
    if not condition:
        return jsonify({"error": "条件不能为空"}), 400
    try:
        # 简单删除逻辑，实际项目中需更复杂的解析
        deleted_rows = 0
        for i in range(len(table.data) - 1, -1, -1):
            if rsa_encryptor.decrypt_data(table.data[i][0]) == condition:
                del table.data[i]
                deleted_rows += 1
        return jsonify({"message": f"删除了 {deleted_rows} 行"})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# API接口：创建表
@app.route('/api/table', methods=['POST'])
def create_table():
    # 检查用户是否已登录
    if 'username' not in session:
        return jsonify({"error": "未登录"}), 401
    table_name = request.json.get('table_name')
    columns = request.json.get('columns')
    if not table_name or not columns:
        return jsonify({"error": "表名或列定义不能为空"}), 400
    try:
        database.create_table(table_name, columns)
        return jsonify({"message": "表创建成功"})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

# API接口：生成密钥对
@app.route('/api/generate_key_pair', methods=['GET'])
def generate_key_pair():
    public_key, private_key = rsa_encryptor.generate_rsa_keys()
    return jsonify({
        "public_key": public_key.decode(),
        "private_key": private_key.decode()
    })

# 密钥生成页面
@app.route('/generate_key', methods=['GET'])
def generate_key():
    return render_template('generate_key.html')

# 上传密钥页面
@app.route('/upload_key', methods=['GET', 'POST'])
def upload_key():
    if request.method == 'POST':
        # 处理公钥文件上传
        if 'public_key_file' in request.files:
            file = request.files['public_key_file']
            if file.filename != '':
                public_key = file.read().decode('utf-8')
                rsa_encryptor.set_public_key(public_key)
                return "公钥上传成功"
        
        # 处理私钥文件上传
        if 'private_key_file' in request.files:
            file = request.files['private_key_file']
            if file.filename != '':
                private_key = file.read().decode('utf-8')
                rsa_encryptor.set_private_key(private_key)
                return "私钥上传成功"
        
        return "密钥上传失败"
    return render_template('upload_key.html')

if __name__ == '__main__':
    app.run(debug=True)